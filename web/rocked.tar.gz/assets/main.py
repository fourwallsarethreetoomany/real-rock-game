import pygame
import random
import sys
import math
import asyncio

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 666
WHITE = (255, 255, 255) #themissileknowswhereitisatalltimes 
YELLOW = (255, 255, 0)
RED = (255, 0, 0) # player
BLACK = (0, 0, 0)
BLUE = (50, 150, 255) # hostile
ORANGE = (255, 165, 0) #   hostile bullets
MISSILE_SPEED = 8

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("pyjhokmes")
clock = pygame.time.Clock()

# Initialize Font for UI
font = pygame.font.SysFont(None, 18)
double_font = pygame.font.SysFont(None, 36)

class Player(pygame.sprite.Sprite):
    def __init__(self, surface, player_x, player_y, angle=90):
        super().__init__()
        self.angle = angle
        self.original_image = surface
        self.image = surface.copy()
        self.rect = self.image.get_rect()
        
        # Physics attributes
        self.pos = pygame.Vector2(player_x, player_y)
        self.velocity = pygame.Vector2(0, 0)
        self.acceleration = 0.4  # obvious
        self.max_speed = 8.0     #   speed limit
        self.friction = 0.97     # momentum decay 1 mean no decay, % based
        
        self.rect.center = (int(self.pos.x), int(self.pos.y))

    def right(self):
        self.angle -= 4  #   clockwise
        self.rotate_image()

    def left(self):
        self.angle += 4  #   counter-clockwise
        self.rotate_image()

    def forward(self):
        # apply acceleratio 
        forward_vec = self.get_forward_vector()
        self.velocity += forward_vec * self.acceleration

    def update(self):
        # apply friction/drag  
        self.velocity *= self.friction
        
        # Cap the velocity at the maximum speed
        if self.velocity.length() > self.max_speed:
            self.velocity.scale_to_length(self.max_speed)
            
         
        self.pos += self.velocity
        
        # Screen bounds checking 
        if self.pos.x > SCREEN_WIDTH: 
            self.pos.x = SCREEN_WIDTH
            self.velocity.x = 0
        if self.pos.x < 0: 
            self.pos.x = 0
            self.velocity.x = 0
        if self.pos.y > SCREEN_HEIGHT: 
            self.pos.y = SCREEN_HEIGHT
            self.velocity.y = 0
        if self.pos.y < 0: 
            self.pos.y = 0
            self.velocity.y = 0
            
        self.rect.center = (int(self.pos.x), int(self.pos.y))

    def rotate_image(self):
        #keeps rotation smooth from the center
        old_center = self.rect.center
        self.image = pygame.transform.rotate(self.original_image, self.angle - 90)
        self.rect = self.image.get_rect(center=old_center)

    def get_forward_vector(self):
        #calculate dynamic forward direction vector based on current angle
        radians = math.radians(self.angle)
        return pygame.Vector2(math.cos(radians), -math.sin(radians))


class Asteroid(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.radius = random.randint(15, 40)
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        color = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
        pygame.draw.circle(self.image, color, (self.radius, self.radius), self.radius, 2)
        self.rect = self.image.get_rect()
        start_x = random.randint(0, SCREEN_WIDTH - self.rect.width)
        start_y = random.randint(-150, -40)
        self.pos = pygame.math.Vector2(start_x, start_y)
        self.velocity = pygame.math.Vector2(random.uniform(-2, 2), random.uniform(2, 6))

    def update(self):
        self.pos += self.velocity
        self.rect.topleft = (int(self.pos.x), int(self.pos.y))
        
        # reset
        if (self.rect.top > SCREEN_HEIGHT or self.rect.right < 0 or self.rect.left > SCREEN_WIDTH):
            self.pos.y = random.randint(-100, -40)
            self.pos.x = random.randint(0, SCREEN_WIDTH - self.rect.width)
            self.velocity = pygame.math.Vector2(random.uniform(-2, 2), random.uniform(2, 4))


class Missile(pygame.sprite.Sprite):
    def __init__(self, start_x, start_y, target_x, target_y):
        super().__init__()
        #   the missile image
        self.original_image = pygame.Surface((6, 20), pygame.SRCALPHA)
        self.original_image.fill(WHITE)
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.pos = pygame.math.Vector2(start_x, start_y)
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        
        #  vector math to the target (Mouse click)
        target = pygame.math.Vector2(target_x, target_y)
        direction = target - self.pos
        
        #normalize direction vector and set velocity
        if direction.length() > 0:
            direction = direction.normalize()
        else:
            direction = pygame.math.Vector2(0, -1) # straight up if clicked exactly on player
            
        self.velocity = direction * MISSILE_SPEED
        
        # rotate missile to face target visually
        angle = math.degrees(math.atan2(-direction.y, direction.x)) - 90
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def update(self):
        self.pos += self.velocity
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        
        # kill if it leaves the screen
        if (self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT or
            self.rect.right < 0 or self.rect.left > SCREEN_WIDTH):
            self.kill()


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction_vector):
        super().__init__()
        self.image = pygame.Surface((6, 15), pygame.SRCALPHA)
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.pos = pygame.math.Vector2(x, y)
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        # bullet flies in the direction the player was facing
        self.velocity = direction_vector * 12

    def update(self):
        self.pos += self.velocity
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        
        if (self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT or
            self.rect.right < 0 or self.rect.left > SCREEN_WIDTH):
            self.kill()


class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction_vector):
        super().__init__()
        self.image = pygame.Surface((8, 8), pygame.SRCALPHA)
        pygame.draw.circle(self.image, ORANGE, (4, 4), 4)
        self.rect = self.image.get_rect()
        self.pos = pygame.math.Vector2(x, y)
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        # slo bullet directed towards player
        self.velocity = direction_vector * 3

    def update(self):
        self.pos += self.velocity
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        
        if (self.rect.bottom < 0 or self.rect.top > SCREEN_HEIGHT or
            self.rect.right < 0 or self.rect.left > SCREEN_WIDTH):
            self.kill()


class HostileShip(pygame.sprite.Sprite):
    def __init__(self, player_ref, all_sprites_group, enemy_bullets_group):
        super().__init__()
        self.size = 30
        self.radius = 15 # its a circle for collision purposes squares are circles within reason
        self.image = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        pygame.draw.rect(self.image, BLUE, (0, 0, self.size, self.size)) # Blue cube
        self.rect = self.image.get_rect()
        
        self.pos = pygame.Vector2(random.randint(100, SCREEN_WIDTH-100), random.randint(100, SCREEN_HEIGHT-100))
        self.velocity = pygame.Vector2(0, 0)
        
        self.player = player_ref
        self.all_sprites_ref = all_sprites_group
        self.enemy_bullets_ref = enemy_bullets_group
        
        self.speed = 2.5
        self.health = 5
        self.shoot_cooldown = 90 #  fires every 1.5 seconds (at 60fps)
        
        self.rect.center = (int(self.pos.x), int(self.pos.y))

    def update(self):
        #   vector to the player
        vec_to_player = self.player.pos - self.pos
        distance = vec_to_player.length()

        #  maintain distance of 50
        target_distance = 50
        
        if distance > target_distance + 5:
            # moving towards player
            if distance > 0:
                self.velocity = vec_to_player.normalize() * self.speed
        elif distance < target_distance - 5:
            #  moving away from player
            if distance > 0:
                self.velocity = -vec_to_player.normalize() * self.speed
        else:
            #  if in the desired range slow down
            self.velocity *= 0.8
            
        self.pos += self.velocity
        
        # keep the ship within the screen bounds
        self.pos.x = max(self.size//2, min(SCREEN_WIDTH - self.size//2, self.pos.x))
        self.pos.y = max(self.size//2, min(SCREEN_HEIGHT - self.size//2, self.pos.y))
        self.rect.center = (int(self.pos.x), int(self.pos.y))

        # shotting logic
        self.shoot_cooldown -= 1
        if self.shoot_cooldown <= 0:
            self.shoot_cooldown = 90
            if distance > 0:
                bullet_dir = vec_to_player.normalize()
                enemy_bullet = EnemyBullet(self.pos.x, self.pos.y, bullet_dir)
                self.all_sprites_ref.add(enemy_bullet)
                self.enemy_bullets_ref.add(enemy_bullet)


# asteroid bounce physics for ships
def check_ship_asteroid_collisions(ship, ship_radius, asteroids_group):
    for ast in asteroids_group:
        #   asteroid center
        ast_center = ast.pos + pygame.Vector2(ast.radius, ast.radius)
        
        dist_vec = ast_center - ship.pos
        distance = dist_vec.length()
        min_dist = ship_radius + ast.radius
        
        if distance < min_dist:
            if distance == 0:
                distance = 0.01
                dist_vec = pygame.Vector2(0.1, 0)
                
            overlap = min_dist - distance
            normal = dist_vec.normalize()
            
            # push them apart
            ship.pos -= normal * (overlap / 2)
            ast.pos += normal * (overlap / 2)
            
            # bounceeeeee
            ship.velocity, ast.velocity = ast.velocity, ship.velocity


async def main():
    # groups
    all_sprites = pygame.sprite.Group()
    asteroids_group = pygame.sprite.Group()
    bullets_group = pygame.sprite.Group()
    missiles_group = pygame.sprite.Group()
    enemy_bullets_group = pygame.sprite.Group()

    # asteroid spawn helper
    def spawn_asteroid():
        ast = Asteroid()
        all_sprites.add(ast)
        asteroids_group.add(ast)


    score = 0
    game_won = False

    # spawn   Player
    player_surf = pygame.Surface((40, 30), pygame.SRCALPHA)
    pygame.draw.polygon(player_surf, RED, [(20, 0), (0, 30), (40, 30)])
    player = Player(player_surf, SCREEN_WIDTH // 2, SCREEN_HEIGHT - 60, angle=90)
    all_sprites.add(player)

    # spawn the hostile ship
    hostile = HostileShip(player, all_sprites, enemy_bullets_group)
    all_sprites.add(hostile)

    # 12 rocks to start with
    for i in range(12):
        spawn_asteroid()

    running = True
    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            elif event.type == pygame.KEYDOWN and not game_won:
                if event.key == pygame.K_SPACE:
                    forward_vec = player.get_forward_vector()
                    bullet_spawn_pos = player.pos + (forward_vec * 20)
                    bullet = Bullet(bullet_spawn_pos.x, bullet_spawn_pos.y, forward_vec)
                    all_sprites.add(bullet)
                    bullets_group.add(bullet)
                    
            elif event.type == pygame.MOUSEBUTTONDOWN and not game_won:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                missile = Missile(player.pos.x, player.pos.y, mouse_x, mouse_y)
                all_sprites.add(missile)
                missiles_group.add(missile)

        if not game_won:
            # movement input handling, if the game is won the player is frozen
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                player.left()
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                player.right()
            if keys[pygame.K_UP] or keys[pygame.K_w]:
                player.forward()

            # update positions and physics
            all_sprites.update()

            # asteroid bounce physics
            asteroids_list = asteroids_group.sprites()
            for i in range(len(asteroids_list)):
                for j in range(i + 1, len(asteroids_list)):
                    c1 = asteroids_list[i]
                    c2 = asteroids_list[j]
                    
                    dx = (c2.pos.x + c2.radius) - (c1.pos.x + c1.radius)
                    dy = (c2.pos.y + c2.radius) - (c1.pos.y + c1.radius)
                    distance = math.sqrt(dx**2 + dy**2)
                    minimum_distance = c1.radius + c2.radius
                    
                    if distance <= minimum_distance:
                        if distance == 0:
                            distance = 0.01
                            dx, dy = 0.1, 0
                        
                        overlapping = minimum_distance - distance
                        vectorx = dx / distance
                        vectory = dy / distance
                        
                        c1.pos.x -= vectorx * (overlapping / 2)
                        c1.pos.y -= vectory * (overlapping / 2)
                        c2.pos.x += vectorx * (overlapping / 2)
                        c2.pos.y += vectory * (overlapping / 2)
                        
                        c1.velocity.x, c2.velocity.x = c2.velocity.x, c1.velocity.x
                        c1.velocity.y, c2.velocity.y = c2.velocity.y, c1.velocity.y

            # collision of player/hostile with asteroids
            check_ship_asteroid_collisions(player, 20, asteroids_group)
            if hostile.alive():
                check_ship_asteroid_collisions(hostile, hostile.radius, asteroids_group)

            # collision of bullets/missiles with asteroids
            bullet_hits = pygame.sprite.groupcollide(asteroids_group, bullets_group, True, True)
            for hit in bullet_hits:
                score += 1
                spawn_asteroid()
                
            missile_hits = pygame.sprite.groupcollide(asteroids_group, missiles_group, True, True)
            for hit in missile_hits:
                score += 1
                spawn_asteroid()
                
            # collision with enemy ship
            if hostile.alive():
                h_bullet_hits = pygame.sprite.spritecollide(hostile, bullets_group, True)
                h_missile_hits = pygame.sprite.spritecollide(hostile, missiles_group, True)
                
                total_hits = len(h_bullet_hits) + len(h_missile_hits)
                if total_hits > 0:
                    hostile.health -= total_hits
                    if hostile.health <= 0:
                        score += 25
                        hostile.kill()

            # collision with enemy bullets
            pygame.sprite.spritecollide(player, enemy_bullets_group, True)
            
            # win condition
            if score >= 50:
                game_won = True

        # rendering
        screen.fill(BLACK)
        all_sprites.draw(screen)

        # ui text
        score_text = font.render(f"Score: {score} / 50", True, WHITE)
        screen.blit(score_text, (10, 10))

        if hostile.alive():
            dist = int((hostile.pos - player.pos).length())
            dist_text = font.render(f"Distance to Enemy: {dist}px", True, BLUE)
            screen.blit(dist_text, (10, 40))
            
            health_text = font.render(f"Enemy HP: {hostile.health}/5", True, RED)
            screen.blit(health_text, (10, 70))

        if game_won:
            win_text = double_font.render("Play a better game at https://www.beyondallreason.info/download/", True, YELLOW)
            text_rect = win_text.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2))
            screen.blit(win_text, text_rect)

        pygame.display.flip()
        
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


asyncio.run(main())